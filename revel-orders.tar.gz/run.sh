#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/revel-orders" -importPath github.com/canerdogan/revel-orders -srcPath "$SCRIPTPATH/src" -runMode prod
